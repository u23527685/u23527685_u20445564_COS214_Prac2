# u23527685_u20445564_COS214_Prac2
COS 214 PRAC 2 for u23527685 and u20445564

Kai is working on the pizza class
